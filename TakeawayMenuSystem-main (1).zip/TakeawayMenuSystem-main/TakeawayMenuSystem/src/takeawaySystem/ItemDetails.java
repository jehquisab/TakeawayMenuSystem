package takeawaySystem;

public class ItemDetails {
    double price;
    int quantity;

    public ItemDetails(double price, int quantity) {
        this.price = price;
        this.quantity = quantity;
    }
}