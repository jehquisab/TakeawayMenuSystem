# TakeawayMenuSystem
The design and implentation of a takeaway menu system for SMQA

Note before we start: Due to Linux issues on Percy Gee computers, the project has only been tested on windows OS. If there are any problems on Linux, please try it using Windows.

Steps to run the program and test cases.

1. Download and Uncompress the zip file from the submission link. (uncompress by right clicking the zip file and pressing "Extract Here").
   Note for step 1: Please use the zip file in the submission link, as the GitHub zip file that is being downloaded was acting up.
3. Import the folder, using the Eclipse Import option. (File > Import) then select (General > File System) and then browse to the project folder.
4. In order to run from the beginning, run the Login class inside the takeawaySystem package. From there every class should be accessed as per instrunction in the terminal.
5. In order to test, each class will need to be tested separately from the test.blackbox and test.whitebox packages. Some textfiles have been provided for Category Partition Specification proof as per lab examples.
   
